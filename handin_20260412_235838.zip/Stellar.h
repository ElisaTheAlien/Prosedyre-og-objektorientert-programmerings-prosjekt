#include "AnimationWindow.h"
#include "widgets/Button.h"
#include "startScreen.h"
#include "star.h"
#include "constillation.h"
#include "Grid.h"
#include <fstream>
#include <ctime>

class Stellar : public TDT4102::AnimationWindow {
    private: 
    int winWidth;
    int winHeight;

    const TDT4102::Point buttonPosition1 {0, 0};
    const TDT4102::Point buttonPosition2 {winWidth/2, 0};
    const unsigned int buttonWidth = winWidth/2;;
    const unsigned int buttonHeight = winHeight;
    const std::string buttonLabel = "";

    TDT4102::Button OrionButton;
    bool showOrion = false;
    TDT4102::Button BigDipperButton;
    bool showBigDipper = false;
    TDT4102::Button BetegeuseButton;
    bool showBetelguse = false;
    TDT4102::Button RigelButton;
    bool showRigel = false;

    const unsigned int startButtonWidth = 100;
    const unsigned int startButtonHeight = 40;
    const TDT4102::Point startButtonPosition {winWidth/2-50, winHeight/4-20};
    const std::string startButtonLabel = "Begin";
    TDT4102::Button startButton;
    bool begin = false;

    const unsigned int backButtonWidth = 100;
    const unsigned int backButtonHeight = 40;
    const TDT4102::Point backButtonPosition {winWidth-150, winHeight-70};
    const std::string backButtonLabel = "Back";
    TDT4102::Button backButton;

    const unsigned int quitButtonWidth = 100;
    const unsigned int quitButtonHeight = 40;
    const TDT4102::Point quitButtonPosition {winWidth/2-50, winHeight/4+40};
    const std::string quitButtonLabel = "Quit";
    TDT4102::Button quitButton;
    bool quit = false;

    enum class Screen {
        START,
        CONSTELLATION_SELECT,
        ORION_DETAIL,
        BIGDIPPER_DETAIL,
        STAR_DETAIL
    };
    Screen currentScreen = Screen::START;
    
    public: 
    Stellar(TDT4102::Point position, int width, int height, const std::string& title);
    void setFalse();
    void run();

    void OrionCallback();
    void BigDipperCallback(); 
    void BetelguseCallback(); 
    void RigelCallback();
    void startCallback();
    void backCallback();
    void quitCallback();
    void transitionUp(TDT4102::AnimationWindow& window);
    void transitionDown(TDT4102::AnimationWindow& window);
    void transitionRight(TDT4102::AnimationWindow& window);
    void transitionLeft(TDT4102::AnimationWindow& window);
    void logVisit(const std::string& bodyName);
};